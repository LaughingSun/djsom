
function _deepCloneObject (src, dst, cb) {
  var parts = {ite: ite, src: src, dst: dst || (dst = {})}
    , stack = []
    , srcCache = [src]
    , si = srcCache.length
    , dstCache = [dst]
    , di = dstCache.length
    , ite, parts, key, sval, dval, des
    , i, k, o, t

  ; if ( ! (src instanceof Object)) return src

  (res = dst || (dst = {})).__proto__ = Object.create(src.__proto__)
  ; parts = {
    src: src
    , dst: dst
    , ite: Object.getOwnPropertyNames(src)
  }
  do {
    src = parts.src
    ; dst = parts.dst
    ; ite = parts.ite
    ; while (key = ite.shift()) {
      if ((sval = (des = Object.getOwnPropertyDescriptor(src, key)).value) instanceof Object
          && sval.constructor !== Object) {
        if ((i = srcCache.indexOf(sval)) < 0) {
          (dval = dst.hasOwnProperty(key) ? dst[key] : (dst[key] = {}))
              .__proto__ = Object.create(sval.proto)
          ; stack.push({src: srcCache[ci] = sval, dst: dstCache[ci++] = dval
              , ite: ite, key: key})
          ; ite = Object.getOwnPropertyNames(sval)
          ; des = { value: dval, enumerable: des.enumerable }
        }
      }
      Object.defineProperty(dst, key, des)
    }
  } while (parts = stack.shift())

  return res
}
